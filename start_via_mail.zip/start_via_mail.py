import time
import imaplib
import email
import subprocess

def check_emails():
    username = 'your@mail.com'
    password = 'YourPassword'

    while True:
        try:
            mail = imaplib.IMAP4_SSL("imap.YOURMAIL.com", 993)
            mail.login(username, password)
            mail.select("inbox")

            _, data = mail.search(None, 'FROM', 'Sender@yourmail.com')

            mail_ids = data[0].split()

            if mail_ids:
                subprocess.Popen('YOURPATH', shell=True)
                mail.store(mail_ids[0], '+FLAGS', '\\Deleted')
                mail.expunge()

            mail.logout()

        except Exception as e:
            print("Error:", str(e))


        time.sleep(60)

check_emails()
