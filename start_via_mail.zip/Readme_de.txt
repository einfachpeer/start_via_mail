Readme :


Vorkehrungen vor dem ersten Start : 

Öffnen Sie die Aufgabenplanung, indem Sie nach "Aufgabenplanung" suchen und das entsprechende Programm öffnen.
Klicken Sie auf "Aufgabe erstellen..." in der rechten Seitenleiste, um einen neuen Aufgabeneintrag zu erstellen.
Geben Sie einen Namen und eine Beschreibung für die Aufgabe ein.
Unter dem Reiter "Trigger" klicken Sie auf "Neu", um einen neuen Trigger hinzuzufügen.
Wählen Sie "Beim Anmelden" oder "Beim Systemstart" als Trigger aus, je nachdem, wann das Skript ausgeführt werden soll.
Unter dem Reiter "Aktionen" klicken Sie auf "Neu", um eine neue Aktion hinzuzufügen.
Wählen Sie "Programm starten" als Aktionstyp aus.
Geben Sie den Pfad zur Python-Interpreter-Datei (normalerweise "python.exe") als Programm ein. Wenn Sie nicht sicher sind, wo sich die Python-Interpreter-Datei befindet, können Sie python.exe in das Suchfeld eingeben und den Pfad daraus kopieren.
Geben Sie den Pfad zu Ihrem Python-Skript als Argument ein. Stellen Sie sicher, dass Sie den vollständigen Pfad zu Ihrer Python-Skriptdatei angeben.
Klicken Sie auf "OK", um die Aufgabe zu erstellen.
Starten Sie Ihren Computer neu, um zu überprüfen, ob das Skript beim Start von Windows ausgeführt wird.

Installieren sie Python und ein Programm und die .py zu bearbeiten.
In Zeile 7 und 8 tragen sie bitte ihre Email IMAP Userdaten ein.
In Zeile 12 den IMAP Dienst ihres Email Anbieters von dem sie die Mails empfangen wollen.
In Zeile 16 nach FROM die Email von der Befehle gesendet werden.
In Zeile 21 der Pfad der Software die sie starten wollen.

Ich empfehle ihnen ausdrücklich eine neue Email zu erstellen, von der sie die Mails empfangen, da die von mir geschriebene py Datei die Rechte hat Mails abzurufen, zu löschen und das Passwort in der Datei steht.
Bevor sie das Script installieren bitte ich sie die Test.bat als auszuführendes Programm anzugeben und sich testhalber ne Mail zu senden, wenn dies ohne Probleme klappt, den Pfad bitte durch ihr Programm ersetzen.

Zusätzliche Vorkehrungen bei Windows Server :

Drücken Sie die Tastenkombination "Win + R", um das Dialogfeld "Ausführen" zu öffnen.
Geben Sie "gpedit.msc" ein und klicken Sie auf "OK", um den Gruppenrichtlinien-Editor zu öffnen.
Navigieren Sie zu "Computerkonfiguration" -> "Administrative Vorlagen" -> "Windows-Komponenten" -> "Remote Desktop-Dienste" -> "Remote Desktop-Sitzungshost" -> "Sitzungszeitlimits".
Suchen Sie nach der Richtlinie mit dem Namen "Sitzungssperrung nach RDP-Trennung".
Doppelklicken Sie auf diese Richtlinie, um sie zu bearbeiten.
Wählen Sie die Option "Deaktiviert" aus.
Klicken Sie auf "OK", um die Änderungen zu speichern.

Tipps zum nutzen mit Autoklicker :
Da Autoklicker manuell gestartet werden müssen, geben wir dem Python Script noch einen Befehl um dies zu tun und den Autoklicker zu stoppen, falls einer gewünscht ist.
		import pyautogui
                subprocess.Popen('AUTOCLICK DATEI)
                x = STARTKOORDINATE
                y = STARTKOORDINATE          
                pyautogui.click(x, y)
                # Koordinaten der Schließen-Schaltfläche (X) in der oberen rechten Ecke
                close_x = 1910
                close_y = 10

                # Klicke auf die Schließen-Schaltfläche (X) des Fensters
                pyautogui.click(close_x, close_y)

                mail.store(mail_ids[0], '+FLAGS', '\\Deleted')

written by einfachpeer

OPEN SOURCE !